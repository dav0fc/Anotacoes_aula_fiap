package entradaSaidaDados;

import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		
		/*for(String entrada : args) {
			
			System.out.println("O argumento de entreda é  " + entrada);
			
		}*/
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o seu nome");
		System.out.println("O nome digitado é  " + entrada.nextLine());
		
		entrada.close();
		
	}

}

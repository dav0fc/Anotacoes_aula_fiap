package fundamentals;

public class Mochila {
	
	double capacidade;
	String cor;
	String material;
	
	void armazenar() {
		
	}
	
	void abrir() {
		
	}
	
	void transportar() {
		
	}
}

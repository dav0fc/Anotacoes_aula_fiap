package fundamentals;

public class Teste {

	public static void main(String[] args) {
		
		Aluno aluno = new Aluno();
		aluno.nome = "Teste";
		aluno.rm = "RM456789";
		aluno.turma = "2ESPV";
		
		aluno.comer();
		aluno.estudar();
		aluno.perguntar();

	}

}

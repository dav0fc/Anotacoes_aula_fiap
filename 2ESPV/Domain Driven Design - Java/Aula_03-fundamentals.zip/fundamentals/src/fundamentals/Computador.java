package fundamentals;

public class Computador {
	
	String ip;
	String hardware;
	float tamanho;
	
	void pesquisar() {
		
	}
	
	void calcular() {
		
	}

}

package fundamentals;

public class Sala {
	
	String cor;
	int capacidade;
	float temperatura;
	
	void abrir() {
		
	}
	
	void trancar() {
		
	}
	
	void apagarLuz() {
		
	}

}

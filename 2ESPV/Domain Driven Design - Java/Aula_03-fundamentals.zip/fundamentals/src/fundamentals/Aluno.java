package fundamentals;

public class Aluno {
	
	String rm;
	String nome;
	String turma;
	
	void estudar() {
		System.out.println("O aluno " + nome + " RM " + rm + " da turma " + turma + " estuda.");
	}
	
	void perguntar() {
		System.out.println("O aluno " + nome + " RM " + rm + " da turma " + turma + " pergunta.");
	}
	
	void comer() {
		System.out.println("O aluno " + nome + " RM " + rm + " da turma " + turma + " come.");
	}

}
